import { Auth } from '@/service/auth/auth';
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);

  const userId = sessionStorage.getItem('userId');

  if (userId) {
    return true;
  }

  return router.createUrlTree(['/']);
};
