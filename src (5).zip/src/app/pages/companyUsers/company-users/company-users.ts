import { Shared } from '@/service/shared';
import { Component, inject, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Apiservice } from '@/service/apiservice/apiservice';
import { ConfirmationService, MessageService } from 'primeng/api';
import { FormFieldError } from '@/directives/form-field-error';
import { UserGroups } from '@/models/usergroups/usergroups.enum';

@Component({
    selector: 'app-company-users',
    imports: [Shared, ReactiveFormsModule, FormFieldError],
    templateUrl: './company-users.html',
    styleUrl: './company-users.scss'
})
export class CompanyUsers implements OnInit {
    openCompanyUser = false;
    showDepartments = false;

    companyUserList: any;
    userGroupList: any;
    departmentList: any;

    selectedDepartments: number[] = [];

    menuItems: any[] = [];
    selectedCompanyUsers: any;

    filteredData: any;

    userId: number | null = null;

    currentUser = Number(sessionStorage.getItem('userGroupId'));

    currentUserEmail = sessionStorage.getItem('userEmail');
        
    USERGROUPS = UserGroups;

    private fb = inject(FormBuilder);

    constructor(
        private apiService: Apiservice,
        private messageService: MessageService,
        private confirmationService: ConfirmationService
    ) {}

    first = 0;
    offSet = 0;
    pageSize = 10;
    totalRecords = 0;

    actionName = 'Add';

    companyUserForm = this.fb.group({
        userId: [0],
        userName: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
        email: ['', [Validators.required, Validators.maxLength(80), Validators.pattern(/^[a-z0-9.]+$/)]],
        userGroupId: ['', Validators.required],
        userDepartments: this.fb.array([])
    });

    departmentsControl = new FormControl([]);

    assignDepartments(): FormGroup {
        return this.fb.group({
            departmentId: [0]
        });
    }

    ngOnInit(): void {
        this.fetchActiveCompanyUsers();
        this.menuItems = this.getMenuItems();
    }

    get userName() {
        return this.companyUserForm.get('userName');
    }

    get email() {
        return this.companyUserForm.get('email');
    }

    get userGroupId() {
        return this.companyUserForm.get('userGroupId');
    }

    get userDepartments() {
        return this.companyUserForm.get('userDepartments') as FormArray;
    }

    companyUsersApi(data: any) {
        try {
            this.apiService.fetchActiveCompanyUsers(data).subscribe({
                next: (val) => {
                    this.companyUserList = val?.data?.data;
                    this.totalRecords = val?.data?.length ?? 0;
                },
                error: (err) => {
                    console.log(err);

                    if (err.status === 400) {
                        this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error.detail });
                    }
                }
            });
        } catch (error) {
            console.log(error);
        }
    }

    fetchActiveCompanyUsers() {
        try {
            let data = {
                offSet: this.offSet,
                pageSize: this.pageSize
            };

            this.companyUsersApi(data);
        } catch (error) {
            console.log(error);
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Please Try Again!' });
        }
    }

    fetchActiveUserGroups() {
        try {
            this.apiService.fetchActiveUsergroup('').subscribe({
                next: (val) => {
                    this.userGroupList = val.data;
                },
                error: (err) => {
                    console.log(err);
                }
            });
        } catch (error) {
            console.log(error);
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Please Try Again!' });
        }
    }

    fetchActiveDepartments() {
        try {
            this.apiService.fetchActiveDepartments('').subscribe({
                next: (val) => {
                    this.departmentList = val.data;
                },
                error: (err) => {
                    console.log(err);
                }
            });
        } catch (error) {
            console.log(error);
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Please Try Again!' });
        }
    }

    selectedUserGroup(selectedGroupId: number) {
        this.showDepartments = selectedGroupId !== 301 && selectedGroupId !== 316;

        if (selectedGroupId === 318) {
            this.departmentList = this.departmentList.filter((d: any) => d.departmentId === 3 || d.departmentId === 6)
        }
    }

    selectDepartments(selectedIds: number[]) {
        this.selectedDepartments = selectedIds;

        this.userDepartments.clear();

        selectedIds.forEach((id) => {
            this.userDepartments.push(
                this.fb.group({
                    departmentId: id
                })
            );
        });
    }

    addUser() {
        try {
            this.openCompanyUser = true;
            this.actionName = 'Add';
            this.fetchActiveUserGroups();
            this.fetchActiveDepartments();
        } catch (error) {
            console.log(error);
        }
    }

    fetchViewCompanyUser() {
        try {
            const data = {
                userId: this.userId
            };

            this.apiService.viewCompanyUser(data).subscribe({
                next: (val) => {
                    if (val.data.userDepartments.length === 0) {
                        this.showDepartments = false;
                    }
                    const departmentIds = val.data.userDepartments.map((d: any) => d.departmentId);
                    this.departmentsControl.patchValue(departmentIds);

                    const emailPrefix = val.data.email.split('@')[0];

                    this.companyUserForm.patchValue({
                        ...val.data,
                        email: emailPrefix
                    });
                },
                error: (err) => {
                    console.log(err);
                }
            });
        } catch (error) {
            console.log(error);
        }
    }

    editUser(user: any) {
        this.userId = user.userId;
        this.openCompanyUser = true;
        this.actionName = 'Update';
        this.fetchViewCompanyUser();
        this.fetchActiveUserGroups();
        this.fetchActiveDepartments();
        this.showDepartments = user.userGroupId !== 301;
        if (this.actionName === 'Update') {
            this.companyUserForm.get('email')?.disable();
        } else {
            this.companyUserForm.get('email')?.enable();
        }
        if (!this.showDepartments && user.isDefault) {
            this.companyUserForm.get('userGroupId')?.disable();
        } else {
            this.companyUserForm.get('userGroupId')?.enable();
        }
    }

    onSubmit() {
        try {
            if (this.actionName == 'Add') {
                const emailPrefix = this.companyUserForm.get('email')?.value?.trim();
                let data = {
                    ...this.companyUserForm.value,
                    email: emailPrefix ? `${emailPrefix}@envision-energy.com` : null
                };
                this.apiService.createCompanyUsers(data).subscribe({
                    next: (res) => {
                        this.messageService.add({ severity: 'success', summary: 'Success', detail: 'User Created Successfully' });
                        this.openCompanyUser = false;
                        this.companyUserForm.reset();
                        this.userDepartments.clear();
                        this.departmentsControl.reset();
                        this.fetchActiveCompanyUsers();
                    },
                    error: (error) => {
                        console.log(error);

                        if (error.status === 400) {
                            this.messageService.add({ severity: 'error', summary: 'Error', detail: error.error.detail });
                        }
                    }
                });
            } else if (this.actionName == 'Update') {
                this.companyUserForm.get('email')?.enable();
                this.companyUserForm.get('userGroupId')?.enable();
                const emailPrefix = this.companyUserForm.get('email')?.value?.trim();
                const data = {
                    ...this.companyUserForm.value,
                    email: emailPrefix ? `${emailPrefix}@envision-energy.com` : null
                };
                this.companyUserForm.get('email')?.disable();
                this.companyUserForm.get('userGroupId')?.disable();

                if (!data.userDepartments?.length && this.showDepartments) {
                    const existingDepartments = this.departmentsControl.value?.map((id: number) => ({ departmentId: id }));
                    data.userDepartments = existingDepartments;
                }

                this.apiService.updateCompanyUser(data).subscribe({
                    next: (val) => {
                        this.messageService.add({ severity: 'success', summary: 'Success', detail: 'User Updated Successfully' });
                        this.openCompanyUser = false;
                        this.companyUserForm.reset();
                        this.departmentsControl.reset();
                        this.companyUsersApi(this.filteredData);
                    },
                    error: (err) => {
                        console.log(err);

                        if (err.status === 400) {
                            this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error.detail });
                        }
                    }
                });
            }
        } catch (e) {
            console.log(e);
        }
    }

    deleteUser(user: any) {
        this.confirmationService.confirm({
            message: 'Do you want to delete this record?',
            header: `Delete ${user.userName}`,
            icon: 'pi pi-info-circle',
            rejectLabel: 'Cancel',
            rejectButtonProps: {
                label: 'Cancel',
                severity: 'secondary',
                outlined: true
            },
            acceptButtonProps: {
                label: 'Delete',
                severity: 'danger'
            },
            accept: () => {
                try {
                    const data = {
                        userId: user.userId
                    };

                    this.apiService.deleteCompanyUser(data).subscribe({
                        next: (val) => {
                            this.messageService.add({ severity: 'success', summary: 'Success', detail: 'User Deleted Successfully' });
                            this.fetchActiveCompanyUsers();
                        },
                        error: (err) => {
                            console.log(err);
                        }
                    });
                } catch (error) {
                    console.log(error);
                }
            }
        });
    }

    exportToExcel(){
        const emailText = this.currentUserEmail ?? 'your email address';

        this.confirmationService.confirm({
            message: `The Excel file will be sent to ${emailText}. Do you want to proceed?`,
            header: 'Confirmation',
            closable: true,
            closeOnEscape: true,
            icon: 'pi pi-exclamation-triangle',
            rejectButtonProps: {
                label: 'Cancel',
                severity: 'secondary',
                outlined: true
            },
            acceptButtonProps: {
                label: 'OK'
            },
            accept: () => {
                try {
                    const data = {
                        ...this.filteredData,
                        export: true
                    };

                    this.apiService.fetchActiveCompanyUsers(data).subscribe({
                        next: (val) => {
                            this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Excel file successfully send to email' });
                        }
                    });
                } catch (error) {
                    console.log(error);
                }
            }
        });
    }

    companyUserMenu(event: Event, menu: any, companyUsers: any) {
        this.selectedCompanyUsers = companyUsers;
        menu.toggle(event);

        this.menuItems[1].visible = !companyUsers.isDefault;
    }

    getMenuItems() {
        return [
            {
                label: 'Edit',
                icon: 'pi pi-pencil',
                command: () => this.editUser(this.selectedCompanyUsers)
            },
            {
                label: 'Delete',
                icon: 'pi pi-trash',
                command: () => this.deleteUser(this.selectedCompanyUsers)
            }
        ];
    }

    loadCompanyUser(event: any) {
        try {
            this.first = event.first;
            this.offSet = event.first / event.rows;
            this.pageSize = event.rows;

            const filters = event.filters;

            this.filteredData = {
                offSet: this.offSet,
                pageSize: this.pageSize,
                userName: filters?.userName?.[0]?.value ?? null,
                email: filters?.email?.[0]?.value ?? null,
                userGroupName: filters?.userGroupName?.[0]?.value ?? null
            };

            this.companyUsersApi(this.filteredData);
        } catch (error) {
            console.log(error);
        }
    }

    onDialogClose() {
        this.userId = null;
        this.companyUserForm.reset();
        this.showDepartments = false;
        this.companyUserForm.get('email')?.enable();
        this.departmentsControl.reset();
    }
}
