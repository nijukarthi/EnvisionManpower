import { PurchaseOrderStatus } from '@/models/purchase-order-status/purchase-order-status.enum';
import { Apiservice } from '@/service/apiservice/apiservice';
import { Shared } from '@/service/shared';
import { Component, inject, OnInit } from '@angular/core';
import { FormArray, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { FormFieldError } from '@/directives/form-field-error';
import { UserGroups } from '@/models/usergroups/usergroups.enum';

@Component({
    selector: 'app-invoice-submission-form',
    imports: [Shared, FormFieldError],
    templateUrl: './invoice-submission-form.html',
    styleUrl: './invoice-submission-form.scss'
})
export class InvoiceSubmissionForm implements OnInit {
    offSet = 0;
    pageSize = 100;
    invoiceId = 0;
    currentPOId = 0;

    poList: any;
    poDetails: any;
    poEmployeeList: any;

    selectedEmployees: number[] = [];
    selectedPO: any[] = [];

    UserGroups = UserGroups;

    currentUser = Number(sessionStorage.getItem('userGroupId'));

    private fb = inject(FormBuilder);

    constructor(
        private apiService: Apiservice,
        private messageService: MessageService,
        private router: Router,
        private route: ActivatedRoute
    ) {}

    invoiceForm = this.fb.group({
        invoiceNumber: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(30)]],
        poId: ['', Validators.required],
        year: [null as Date | null],
        sealAndSignDate: ['', Validators.required],
        isPoCopyAttached: [false],
        invoiceDate: ['', Validators.required],
        pod: ['', Validators.required],
        submittedOn: [''],
        month: [null as Date | null, Validators.required],
        submittedTo: ['', [Validators.required, Validators.maxLength(30)]],
        items: this.fb.array([])
    });

    get items() {
        return this.invoiceForm.get('items') as FormArray;
    }

    poEmployeeDetails(emp: any) {
        return this.fb.group({
            employmentId: [emp.employmentDetails.employmentId],
            sacCode: [emp.sacCode ?? '', [Validators.required, Validators.maxLength(20)]]
        });
    }
    get invoiceNumber() {
        return this.invoiceForm.get('invoiceNumber');
    }
    get poId() {
        return this.invoiceForm.get('poId');
    }
    get sealAndSignDate() {
        return this.invoiceForm.get('sealAndSignDate');
    }
    get invoiceDate() {
        return this.invoiceForm.get('invoiceDate');
    }
    get pod() {
        return this.invoiceForm.get('pod');
    }
    get month() {
        return this.invoiceForm.get('month');
    }
    get submittedTo() {
        return this.invoiceForm.get('submittedTo');
    }
    getsacCode(index: number) {
        return this.items.at(index).get('sacCode');
    }

    isPoCopyAttached = [
        {
            label: 'Yes',
            value: true
        },
        {
            label: 'No',
            value: false
        }
    ];

    ngOnInit(): void {
        this.fetchPOList();

        this.route.paramMap.subscribe((param) => {
            const id = param.get('id');

            if (id) {
                this.invoiceId = Number(id);
                this.fetchViewInvoice();
            }
        });
    }

    fetchPOList() {
        try {
            const data = {
                offSet: this.offSet,
                pageSize: this.pageSize,
                poStatus: PurchaseOrderStatus.ACTIVE
            };


            this.apiService.fetchPOList(data).subscribe({
                next: (val) => {
                    this.poList = val.data.data.map((po: any) => {
                        const start = new Date(po.validFrom);
                        const end = new Date(po.validTo);

                        const months = (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - end.getMonth());

                        return {
                            ...po,
                            duration: months
                        };
                    });
                },
                error: (err) => {
                    console.log(err);
                }
            });
        } catch (error) {
            console.log(error);
        }
    }

    fetchViewInvoice() {
        try {
            const data = {
                invoiceId: this.invoiceId
            };

            this.apiService.fetchViewInvoice(data).subscribe({
                next: (val) => {
                    const invoiceData = val?.data?.header;

                    this.invoiceForm.patchValue({
                        ...invoiceData,
                        invoiceDate: new Date(invoiceData?.invoiceDate),
                        sealAndSignDate: new Date(invoiceData.sealAndSignDate),
                        month: new Date(invoiceData.year, invoiceData.month - 1, 1),
                        year: new Date(invoiceData.year, 0, 1),
                        submittedOn: new Date(invoiceData.submittedOn)
                    });
                    this.poEmployeeList = val?.data?.items;
                    this.poDetails = this.poList.find((po: any) => po.poId === val?.data?.header?.poId);

                    this.items.clear();
                    this.poEmployeeList.forEach((emp: any) => {
                        this.items.push(this.poEmployeeDetails(emp));
                    });
                },
                error: (err) => {
                    console.log(err);
                }
            });
        } catch (error) {
            console.log(error);
        }
    }

    convertMonthAndYear() {
        const selectedMonth = this.invoiceForm.get('month')?.value;
        if (!selectedMonth) {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Month & Year not selected' });
            return;
        }
        const month = selectedMonth?.getMonth() + 1;

        const year = selectedMonth.getFullYear();

        return { month, year };
    }

    selectedPOId(poId: number) {
        try {
            this.currentPOId = poId;
            this.poDetails = this.poList.find((po: any) => po.poId === poId);
        } catch (error) {
            console.log(error);
        }
    }

    getLineItems() {
        try {
            const monthYear = this.convertMonthAndYear();

            const data = {
                poId: this.currentPOId,
                month: monthYear?.month,
                year: monthYear?.year
            };

            this.apiService.fetchPODetails(data).subscribe({
                next: (val) => {
                    this.poEmployeeList = val?.data;
                    this.items.clear();
                    this.poEmployeeList?.forEach((emp: any) => {
                        this.items?.push(this.poEmployeeDetails(emp));
                    });
                },
                error: (err) => {
                    console.log(err);
                }
            });
        } catch (error) {
            console.log(error);
        }
    }

    selectAll(selection: any){
        this.selectedEmployees = selection
        .filter((emp: any) => emp.eligible === true)
        .map((emp: any) => emp.employmentDetails?.employmentId);
    }

    formatDate(date: Date | null | string | undefined): string | null {
        if (!date) return null;
        const d = new Date(date);
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    onSubmit() {
        try {
            const formValue = this.invoiceForm.value;

            const monthYear = this.convertMonthAndYear();

            const filteredItems = formValue.items?.filter((item: any) => this.selectedEmployees.includes(item.employmentId));

            const data = {
                ...formValue,
                sealAndSignDate: this.formatDate(formValue.sealAndSignDate),
                invoiceDate: this.formatDate(formValue.invoiceDate),
                submittedOn: this.formatDate(formValue.submittedOn),
                month: monthYear?.month,
                year: monthYear?.year,
                items: filteredItems
            };

            this.apiService.createInvoice(data).subscribe({
                next: (val) => {
                    this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Invoice Created Sucessfully' });

                    setTimeout(() => {
                        this.router.navigate(['/home/invoice-submission']);
                    }, 2000);
                },
                error: (err) => {
                    console.log(err);

                    if (err.status === 400) {
                        this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error.detail });
                    }
                }
            });
        } catch (error) {
            console.log(error);
        }
    }
}
