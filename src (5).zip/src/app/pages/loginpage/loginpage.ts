import { UserGroups } from '@/models/usergroups/usergroups.enum';
import { Apiservice } from '@/service/apiservice/apiservice';
import { Auth } from '@/service/auth/auth';
import { Shared } from '@/service/shared';
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { TabsModule } from 'primeng/tabs';

@Component({
  selector: 'app-loginpage',
  imports: [Shared, TabsModule],
  templateUrl: './loginpage.html',
  styleUrl: './loginpage.scss'
})
export class Loginpage {
  enteredLoginUserEmail = '';
  otpTimeLeft = '';
  loginUserResponse: any;
  loginUserForm: any;
  loginScreen:boolean = true;
  registerScreen:boolean = false;
  registerInterviewerScreen = false;
  userOtpForm:any;
  interviewerForm: any;
  interviewerOtpForm: any;

  UserGroups = UserGroups;

  constructor(private messageService: MessageService, 
    private apiService: Apiservice, private fb: FormBuilder,
    private route:Router, private authService: Auth) { }

  ngOnInit(): void {
    sessionStorage.clear();
    this.loginUserForm = this.fb.group({
      email: ['',(Validators.required,Validators.email)],
    })

    this.userOtpForm = this.fb.group({
        email: [''],
        otp: ['',Validators.required]
    })

    this.interviewerForm = this.fb.group({
        phoneNumber: ['',Validators.required]
    })

    this.interviewerOtpForm = this.fb.group({
        phoneNumber: [''],
        otp: ['', Validators.required]
    })
  }

    otpTimer(expireByString: string){
        const expireBy = new Date(expireByString).getTime();

        const interval = setInterval(() => {
            const currentTime = Date.now();

            const diffMs = expireBy - currentTime;

            if (diffMs <= 0) {
                clearInterval(interval);
                this.otpTimeLeft = '00:00';
                return;
            }

            const totalSeconds = Math.floor(diffMs / 1000);
            const minutes = Math.floor(totalSeconds / 60);
            const seconds = totalSeconds % 60;

            this.otpTimeLeft = `${this.pad(minutes)}:${this.pad(seconds)}`;
        }, 1000)
    }

    pad(num: number): string{
        return num < 10 ? '0' + num : '' + num;
    }

    onSubmitUsers(action:any){
        try{
            if (action == 'email') {
                 this.enteredLoginUserEmail = this.loginUserForm.get('email')?.value ?? '';
                this.loginUserForm.get('email')?.setValidators([
                    Validators.required,
                ]);
                this.loginUserForm.get('email')?.updateValueAndValidity();

                this.interviewerForm.get('phoneNumber')?.clearValidators();
                this.interviewerForm.get('phoneNumber')?.updateValueAndValidity();

                if(this.loginUserForm.valid){
                    var email = this.loginUserForm.get('email')?.value;
                    let data = {
                        "email": email
                    }
                    this.apiService.sendOTP(data).subscribe({
                    next: val => {
                        if(val.status == 200){
                            this.registerScreen = true;
                            this.loginScreen = false;
                            this.loginUserResponse = val.data;
                            this.otpTimer(this.loginUserResponse.expireBy);
                            return;
                        }
                        this.registerScreen = false;
                        this.loginScreen = true;
                    },
                    error: err => {
                        console.log(err);
                      this.registerScreen = false;
                        this.loginScreen = true;
                        this.messageService.add({ severity: 'error', summary: 'Error', detail: err?.error?.detail });
                    }
                })
                }else{
                 this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Please Enter Email Id' });
                }
               

            } else if (action == 'guest') {
                this.interviewerForm.get('phoneNumber')?.setValidators([
                    Validators.required,
                    Validators.pattern('^[0-9]{10}$')
                ]);
                this.interviewerForm.get('phoneNumber')?.updateValueAndValidity();

                 this.loginUserForm.get('email')?.clearValidators();
                this.loginUserForm.get('email')?.updateValueAndValidity();
                this.loginUserForm.updateValueAndValidity();

                if(this.loginUserForm.valid){
                    var phoneNumber = this.loginUserForm.get('phoneNumber')?.value;
                    let data = {
                        "email": phoneNumber
                    }
                    this.apiService.sendOTP(data).subscribe({
                    next: val => {
                        if(val.status == 200){
                           this.registerScreen = true;
                            this.loginScreen = false;
                            this.loginUserResponse = val;
                            this.otpTimer(this.loginUserResponse.expireBy);
                            return;
                        }
                         this.registerScreen = false;
                            this.loginScreen = true;
                    },
                    error: err => {
                       this.registerScreen = false;
                            this.loginScreen = true;
                        this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error.detail });
                    }
                })
                }else{
                 this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Please Mobile Number' });
                }

            }
             
             

        }catch(e){
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Message Content' });
        }
       
    }

    submitInterviewer(){
        try {
            if (this.interviewerForm.valid) {
                const data = this.interviewerForm.value;
                this.apiService.sendInterviewerOtp(data).subscribe({
                    next: val => {
                        this.loginScreen = false;
                        this.registerInterviewerScreen = true;
                        this.loginUserResponse = val.data;
                        this.otpTimer(this.loginUserResponse.expireBy);
                        return;
                    },
                    error: err => {
                        console.log(err);
                        this.loginScreen = true;
                        this.registerInterviewerScreen = false;

                        if (err.status === 400) {
                            this.messageService.add({severity: 'error', summary: 'Error', detail: err.error.detail})
                        }
                    }
                })
            }else{
                this.messageService.add({severity: 'error', summary: 'Error', detail: 'Please Enter Mobile Number'})
            }
        } catch (error) {
            console.log(error);
        }
    }


    verifyOtp(){
        try{
            if(this.userOtpForm.valid){
                this.userOtpForm.patchValue({
                    email: this.loginUserResponse.email
                })

                this.apiService.verifyUserOtp(this.userOtpForm.value).subscribe({
                    next: (val: any) => { 
                        this.authService.checkSessionAndNavigate().subscribe(val => {
                            if(!val) return;

                            if (this.route.url === '/' || this.route.url === ''){
                                switch(val.data.userGroupId){
                                    case UserGroups.CLUSTERHEAD:
                                    case UserGroups.DEPARTMENTHEAD:
                                        this.route.navigate(['/home/manpower-approval']);
                                        break;
                        
                                    case UserGroups.CONSULTANCY:
                                        this.route.navigate(['/home/consultancies']);
                                        break;
                        
                                    case UserGroups.READONLYADMIN:
                                        this.route.navigate(['/home/onroll-employees']);
                                        break;
                        
                                    case UserGroups.GUESTUSER:
                                        this.route.navigate(['/home/manpower-fulfillment']);
                                        break;

                                    case UserGroups.DPRMANAGEMENTTEAM:
                                        this.route.navigate(['/home/dpr-project-details']);
                                        break;
                        
                                    case UserGroups.ADMIN:
                                        // this.route.navigate(['/home/dashboard']);
                                        // break;

                                    case UserGroups.SITEINCHARGE:
                                    case UserGroups.PROJECTMANAGER:
                                    case UserGroups.RESOURCEMANAGER:
                                    case UserGroups.ACCOUNTSRECEIVABLETEAM:
                                    case UserGroups.SERVICEMANAGER:
                                        this.route.navigate(['/home/manpower-request']);
                                }
                            }
                        });

                    },
                    error: err => {
                        console.log(err);
                        this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error.detail });

                    }
                })
            }   else{
                this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Please Enter OTP' });
            }
        }catch(e){
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Please Try Again' });
        }
        
    }

    verifyInterviewerOtp(){
        try {
            if (this.interviewerOtpForm.valid) {
                this.interviewerOtpForm.patchValue({
                    phoneNumber: this.loginUserResponse.email
                })

                const data = this.interviewerOtpForm.value;

                this.apiService.verifyInterviewerOtp(data).subscribe({
                    next: val => {
                        this.authService.checkSessionAndNavigate().subscribe(val => {
                            if(!val) return;

                                if (this.route.url === '/' || this.route.url === '') {         
                                    switch(val.data.userGroupId){
                                        case UserGroups.CLUSTERHEAD:
                                        case UserGroups.DEPARTMENTHEAD:
                                            this.route.navigate(['/home/manpower-approval']);
                                            break;
                            
                                        case UserGroups.CONSULTANCY:
                                            this.route.navigate(['/home/consultancies']);
                                            break;
                            
                                        case UserGroups.READONLYADMIN:
                                            this.route.navigate(['/home/onroll-employees']);
                                            break;
                            
                                        case UserGroups.GUESTUSER:
                                            this.route.navigate(['/home/manpower-fulfillment']);
                                            break;
                            
                                        case UserGroups.ADMIN:
                                        case UserGroups.SITEINCHARGE:
                                        case UserGroups.PROJECTMANAGER:
                                        case UserGroups.RESOURCEMANAGER:
                                        case UserGroups.ACCOUNTSRECEIVABLETEAM:
                                            this.route.navigate(['/home/manpower-request']);
                                    }
                                }
                        });
                    },
                    error: err => {
                        console.log(err);

                        if (err.status === 400) {
                            this.messageService.add({severity: 'error', summary: 'Error', detail: err.error.detail});
                        }
                    }
                })
            }
        } catch (error) {
            console.log(error);
        }
    }


}
