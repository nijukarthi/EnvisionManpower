import { Apiservice } from '@/service/apiservice/apiservice';
import { Shared } from '@/service/shared';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-audit-log',
    imports: [Shared],
    templateUrl: './activity-log.html',
    styleUrl: './activity-log.scss'
})
export class ActivityLog implements OnInit {
    offSet = 0;
    pageSize = 10;
    first = 0;
    totalRecords = 0;

    filteredData: any;

    logsList: any;

    constructor(private apiService: Apiservice) {}

    ngOnInit(): void {
        this.fetchLogsList();
    }

    auditLogApi(data: any) {
        try {
            this.apiService.logsList(data).subscribe({
                next: (val) => {
                    this.logsList = val?.data?.data;
                    this.totalRecords = val?.data?.length ?? 0;
                },
                error: (err) => {
                    console.log(err);
                }
            });
        } catch (error) {
            console.log(error);
        }
    }

    fetchLogsList(isRefresh = false) {
        try {
            if (isRefresh) {
                this.offSet = 0;
                this.first = 0;
            }

            const data = {
                offSet: this.offSet,
                pageSize: this.pageSize
            };

            this.auditLogApi(data);
        } catch (error) {
            console.log(error);
        }
    }

    private formatDateForApi(date: Date, isEndDate = false) {
        if (!date) return null as any;

        const yyyy = date.getFullYear();
        const mm = String(date.getMonth() + 1).padStart(2, '0');
        const dd = String(date.getDate()).padStart(2, '0');

        const time = isEndDate ? '23:59:59' : '00:00:00';

        return `${yyyy}-${mm}-${dd}T${time}Z`;
    }

    getFilterValues(filters: any, field: string): string[] | null {
        const rules = filters?.[field];
        if (!Array.isArray(rules)) return null;

        const values = rules.map((rule) => rule?.value).filter((v) => v !== null && v !== '');

        return values.length ? values : null;
    }

    loadAuditLog(event: any) {
        try {
            this.first = event.first;
            this.offSet = event.first / event.rows;
            this.pageSize = event.rows;

            const filters = event.filters;

            const dateValue = filters?.date?.[0]?.value;

            const from = Array.isArray(dateValue) ? dateValue[0] : null;
            const to = Array.isArray(dateValue) ? dateValue[1] : null;

            this.filteredData = {
                offSet: this.offSet,
                pageSize: this.pageSize,
                jti: filters?.sessionId?.[0]?.value ?? null,
                username: filters?.userName?.[0]?.value ?? null,
                userGroupName: filters?.userGroupName?.[0]?.value ?? null,
                emailOrPhone: filters?.emailOrPhone?.[0]?.value ?? null,
                fromDate: from ? this.formatDateForApi(from, false) : null,
                toDate: to ? this.formatDateForApi(to, true) : null,
                actions: this.getFilterValues(filters, 'actions')
            };

            this.auditLogApi(this.filteredData);
        } catch (error) {
            console.log(error);
        }
    }

    updateRange(selectedValue: any, value: any[], index: number, filter: any) {
        if (!value) value = [];

        value[index] = selectedValue;

        filter(value);
    }

    getSeverity(status: string){
        switch(status){
            case 'SUCCESS':
                return 'success';
            case 'FAILURE':
                return 'danger';
            default:
                return 'primary';
        }
    }
}
