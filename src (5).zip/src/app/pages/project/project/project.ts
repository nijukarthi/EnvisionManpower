import { UserGroups } from '@/models/usergroups/usergroups.enum';
import { Apiservice } from '@/service/apiservice/apiservice';
import { Shared } from '@/service/shared';
import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ConfirmationService, MessageService } from 'primeng/api';
import { FormFieldError } from '@/directives/form-field-error';

@Component({
    selector: 'app-project',
    imports: [Shared, FormFieldError],
    templateUrl: './project.html',
    styleUrl: './project.scss'
})
export class Project implements OnInit {
    openProject = false;
    loading = false;

    projectId: number | null = null;

    menuItems: any[] = [];
    selectedProject: any;

    currentUser = Number(sessionStorage.getItem('userGroupId'));

    currentUserEmail = sessionStorage.getItem('userEmail');

    UserGroups = UserGroups;

    first = 0;
    offSet = 0;
    pageSize = 10;
    totalRecords = 0;

    filteredData: any;

    actionName = '';
    siteName = '';

    private fb = inject(FormBuilder);
    experience: any;

    constructor(
        private apiService: Apiservice,
        private messageService: MessageService,
        private confirmationService: ConfirmationService
    ) {}

    projectList: any;
    clusterList: any[] = [];
    clusterHeadList: any;
    siteInchargeList: any;
    departmentList: any;
    departmentHeadList: any;

    projectForm = this.fb.group({
        projectId: [0],
        projectCode: ['', [Validators.required, Validators.maxLength(20)]],
        siteName: ['', [Validators.required, Validators.maxLength(50)]],
        cluster: this.fb.group({
            clusterId: [null, Validators.required]
        }),
        siteIncharge: this.fb.group({
            userId: [null, Validators.required]
        }),
        clusterHead: this.fb.group({
            userId: [null, Validators.required]
        }),
        department: this.fb.group({
            departmentId: [null, Validators.required]
        }),
        departmentHead: this.fb.group({
            userId: [null, Validators.required]
        })
    });

    get projectCode() {
        return this.projectForm.get('projectCode');
    }

    get site() {
        return this.projectForm.get('siteName');
    }

    get cluster() {
        return this.projectForm.get('cluster.clusterId');
    }

    get siteIncharge() {
        return this.projectForm.get('siteIncharge.userId');
    }

    get clusterHead() {
        return this.projectForm.get('clusterHead.userId');
    }

    get department() {
        return this.projectForm.get('department.departmentId');
    }

    get departmentHead() {
        return this.projectForm.get('departmentHead.userId');
    }

    ngOnInit(): void {
        this.menuItems = this.getMenuItems();
        this.fetchActiveProjects();
        this.fetchActiveDepartments();
    }

    getMenuItems() {
        return [
            {
                label: 'Edit',
                icon: 'pi pi-pencil',
                command: () => this.editProject(this.selectedProject)
            },
            {
                label: 'Delete',
                icon: 'pi pi-trash',
                command: () => this.deleteProject(this.selectedProject)
            }
        ];
    }

    projectApi(data: any) {
        try {
            this.apiService.fetchActiveProjects(data).subscribe({
                next: (val) => {
                    console.log(val);
                    this.projectList = val?.data.data;
                    this.totalRecords = val?.data.length ?? 0;
                },
                error: (err) => {
                    console.log(err);
                }
            });
        } catch (error) {
            console.log(error);
        }
    }

    fetchActiveProjects() {
        try {
            let data = {
                offSet: this.offSet,
                pageSize: this.pageSize
            };
            console.log(data);
            this.projectApi(data);
        } catch (error) {
            console.log(error);
        }
    }

    fetchAllCluster() {
        try {
            this.apiService.getActiveClusters('').subscribe({
                next: (val) => {
                    console.log(val);
                    this.clusterList = val.data;
                },
                error: (err) => {
                    console.log(err);
                }
            });
        } catch (error) {
            console.log(error);
        }
    }

    fetchClusterHeadByCluster(clusterId: number) {
        console.log(clusterId);
        console.log('checking');
        try {
            const data = {
                clusterId: clusterId
            };
            console.log(data);
            this.apiService.fetchClusterHeadByCluster(data).subscribe({
                next: (val) => {
                    console.log(val);
                    this.clusterHeadList = val.data ? [val.data] : [];
                },
                error: (err) => {
                    console.log(err);
                }
            });
        } catch (error) {
            console.log(error);
        }
    }

    fetchDepartmentHeadByDepartment(departmentId: number) {
        try {
            const data = {
                departmentId: departmentId
            };
            console.log(data);

            this.apiService.fetchDepartmentHeadByDepartment(data).subscribe({
                next: (val) => {
                    console.log(val);
                    this.departmentHeadList = val.data ? [val.data] : [];
                },
                error: (err) => {
                    console.log(err);
                }
            });
        } catch (error) {
            console.log(error);
        }
    }

    fetchActiveDepartments() {
        this.apiService.fetchActiveDepartments('').subscribe({
            next: (val) => {
                console.log(val);
                this.departmentList = val.data;
            },
            error: (err) => {
                console.log(err);
            }
        });
    }

    findUserGroup(userGroupId: number, type: 'siteIncharge' | 'departmentHead') {
        try {
            this.loading = true;

            const data = {
                userGroupId: userGroupId
            };
            console.log(data);
            this.apiService.findUserGroup(data).subscribe({
                next: (val) => {
                    console.log(val);
                    if (type === 'siteIncharge') {
                        this.siteInchargeList = val?.data;
                    } else if (type === 'departmentHead') {
                        this.departmentHeadList = val?.data;
                    }
                    this.loading = false;
                },
                error: (err) => {
                    console.log(err);
                    this.loading = false;
                }
            });
        } catch (error) {
            console.log(error);
        }
    }

    addProject() {
        try {
            this.openProject = true;
            this.actionName = 'Save';
            this.fetchAllCluster();
        } catch (error) {
            console.log(error);
        }
    }

    editProject(project: any) {
        try {
            this.projectId = project.projectId;
            this.openProject = true;
            this.actionName = 'Update';
            this.fetchAllCluster();
            this.fetchClusterHeadByCluster(project.cluster.clusterId);
            this.findUserGroup(UserGroups.SITEINCHARGE, 'siteIncharge');
            this.findUserGroup(UserGroups.DEPARTMENTHEAD, 'departmentHead');
            this.siteName = project.siteName;
            this.projectForm.patchValue({
                projectId: project.projectId,
                projectCode: project.projectCode,
                siteName: project.siteName,
                cluster: {
                    clusterId: project.cluster.clusterId
                },
                siteIncharge: {
                    userId: project.siteIncharge.userId
                },
                clusterHead: {
                    userId: project.clusterHead.userId
                },
                department: {
                    departmentId: project.department.departmentId
                },
                departmentHead: {
                    userId: project.departmentHead.userId
                }
            });
        } catch (error) {
            console.log(error);
        }
    }

    onSubmit() {
        try {
            console.log(this.projectForm.value);
            if (!this.projectId) {
                if (this.projectForm.valid) {
                    const data = {
                        projectCode: this.projectForm.get('projectCode')?.value,
                        siteName: this.projectForm.get('siteName')?.value,
                        cluster: {
                            clusterId: this.projectForm.get('cluster.clusterId')?.value
                        },
                        siteIncharge: {
                            userId: this.projectForm.get('siteIncharge.userId')?.value
                        },
                        clusterHead: {
                            userId: this.projectForm.get('clusterHead.userId')?.value
                        },
                        department: {
                            departmentId: this.projectForm.get('department.departmentId')?.value
                        },
                        departmentHead: {
                            userId: this.projectForm.get('departmentHead.userId')?.value
                        }
                    };
                    this.apiService.createNewProject(data).subscribe({
                        next: (val) => {
                            console.log(val);
                            this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Project Created Successfully' });
                            this.openProject = false;
                            this.projectForm.reset();
                            this.fetchActiveProjects();
                        },
                        error: (err) => {
                            console.log(err);

                            if (err.status === 400) {
                                this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error.detail });
                            }
                        }
                    });
                }
            } else {
                if (this.projectForm.valid) {
                    const data = {
                        projectId: this.projectForm.get('projectId')?.value,
                        projectCode: this.projectForm.get('projectCode')?.value,
                        siteName: this.projectForm.get('siteName')?.value,
                        cluster: {
                            clusterId: this.projectForm.get('cluster.clusterId')?.value
                        },
                        siteIncharge: {
                            userId: this.projectForm.get('siteIncharge.userId')?.value
                        },
                        clusterHead: {
                            userId: this.projectForm.get('clusterHead.userId')?.value
                        },
                        department: {
                            departmentId: this.projectForm.get('department.departmentId')?.value
                        },
                        departmentHead: {
                            userId: this.projectForm.get('departmentHead.userId')?.value
                        }
                    };
                    this.apiService.updateProject(data).subscribe({
                        next: (val) => {
                            console.log(val);
                            this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Project Updated Successfully' });
                            this.openProject = false;
                            this.projectForm.reset();
                            this.projectApi(this.filteredData);
                        },
                        error: (err) => {
                            console.log(err);

                            if (err.status === 400) {
                                this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error.detail });
                            }
                        }
                    });
                }
            }
        } catch (error) {
            console.log(error);
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Please Try again' });
        }
    }

    exportToExcel(){
        const emailText = this.currentUserEmail ?? 'your email address';

        this.confirmationService.confirm({
            message: `The Excel file will be sent to ${emailText}. Do you want to proceed?`,
            header: 'Confirmation',
            closable: true,
            closeOnEscape: true,
            icon: 'pi pi-exclamation-triangle',
            rejectButtonProps: {
                label: 'Cancel',
                severity: 'secondary',
                outlined: true
            },
            acceptButtonProps: {
                label: 'OK'
            },
            accept: () => {
                try {
                    const data = {
                        ...this.filteredData,
                        export: true
                    };

                    console.log(data);

                    this.apiService.fetchActiveProjects(data).subscribe({
                        next: (val) => {
                            console.log(val);

                            this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Excel file successfully send to email' });
                        }
                    });
                } catch (error) {
                    console.log(error);
                }
            }
        });
    }

    deleteProject(project: any) {
        this.confirmationService.confirm({
            message: 'Do you want to delete this record?',
            header: `Delete ${project.projectCode}`,
            icon: 'pi pi-info-circle',
            rejectLabel: 'Cancel',
            rejectButtonProps: {
                label: 'Cancel',
                severity: 'secondary',
                outlined: true
            },
            acceptButtonProps: {
                label: 'Delete',
                severity: 'danger'
            },
            accept: () => {
                try {
                    const data = {
                        projectId: project.projectId
                    };
                    this.apiService.deleteProject(data).subscribe({
                        next: (val) => {
                            console.log(val);
                            this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Product Deleted Successfully' });
                            this.fetchActiveProjects();
                        },
                        error: (err) => {
                            console.log(err);
                        }
                    });
                } catch (error) {
                    console.log(error);
                }
            }
        });
    }

    projectMenu(event: Event, menu: any, project: any) {
        this.selectedProject = project;
        menu.toggle(event);
    }

    loadProject(event: any) {
        try {
            this.first = event.first;
            this.offSet = event.first / event.rows;
            this.pageSize = event.rows;

            const filters = event.filters;
            console.log(filters);

            this.filteredData = {
                offSet: this.offSet,
                pageSize: this.pageSize,
                projectCode: filters?.projectCode?.[0]?.value ?? null,
                siteName: filters?.siteName?.[0]?.value ?? null,
                clusterName: filters?.clusterName?.[0]?.value ?? null,
                clusterHead: filters?.clusterHead?.[0]?.value ?? null,
                departmentName: filters?.departmentName?.[0]?.value ?? null,
                departmentHead: filters?.departmentHead?.[0]?.value ?? null,
                siteIncharge: filters?.siteIncharge?.[0]?.value ?? null
            };
            console.log(this.filteredData);
            this.projectApi(this.filteredData);
        } catch (error) {
            console.log(error);
        }
    }

    onDialogClose() {
        this.projectId = null;
        this.projectForm.reset();
    }
}
